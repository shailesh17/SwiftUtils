//
//  SwiftUtilsXCFramework.h
//  SwiftUtilsXCFramework
//
//  Created by Shailesh Patel on 5/19/22.
//

#import <Foundation/Foundation.h>

//! Project version number for SwiftUtilsXCFramework.
FOUNDATION_EXPORT double SwiftUtilsXCFrameworkVersionNumber;

//! Project version string for SwiftUtilsXCFramework.
FOUNDATION_EXPORT const unsigned char SwiftUtilsXCFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftUtilsXCFramework/PublicHeader.h>


